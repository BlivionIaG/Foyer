<?php
date_default_timezone_set('Europe/Paris');
	echo date("d m Y H:i");
?>