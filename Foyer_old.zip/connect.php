<?php
$passwd = 'EpnpxDTy';
$login = 'konstantin_sido';
$host = 'konstantin-sidorenko.fr.mysql';
$bdd = 'konstantin_sido';
$db = mysqli_connect($host, $login, $passwd, $bdd);
mysqli_query($db, "SET NAMES UTF8"); 
?>
